<?php
header("Access-Control-Allow-Origin: *");

$name = $_POST['name'];
$author = $_POST['author'];
$category = $_POST['category'];
$isbn = $_POST['isbn'];
$edition = $_POST['edition'];
$price = $_POST['price'];
$description = $_POST['description'];
$image = $_FILES['image']['name'];

$con = new mysqli("localhost", "root", "", "library");
$data = array();

if ($name && $author && $category && $isbn && $edition && $price && $description && $image) {
    $con->query(
        "Insert into books set
                        name = '" . $name . "',
                        author = '" . $author . "',
                        isbn = '" . $isbn . "',
                        edition = '" . $edition . "',
                        price = '" . $price . "',
                        description = '" . $description . "',
                        image = '" . $image . "'"
    );

    $data = array('status' => 1);
} else {
    $data = array('status' => 0);
}
echo json_encode($data);
?>